create
    definer = root@localhost function isHimself(player_id int, opinion_id int) returns tinyint(1) deterministic
BEGIN
        DECLARE res INT;
        SELECT (COUNT(*) = 0) INTO res  FROM OPINION, RELEVANT
        WHERE RELEVANT.id_player = 3
          AND OPINION.id_player = 3
        LIMIT 1;
        RETURN res > 0;
    END;

